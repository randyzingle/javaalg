package computer;

/** A super type for things inserted into the memory 
 * of the toy computer. 
 * @author jbergin
 *
 */
public interface Code{
	
}
