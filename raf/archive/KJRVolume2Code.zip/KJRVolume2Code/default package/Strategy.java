
import com.jbergin.robot.*;

public interface Strategy
{
		public void doIt(Robot which);
}
