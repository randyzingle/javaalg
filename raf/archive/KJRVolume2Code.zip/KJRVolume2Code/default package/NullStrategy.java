
import com.jbergin.robot.*;

public class NullStrategy implements Strategy
{
	public void doIt(Robot which)
	{
		// nothing 
	}
}
