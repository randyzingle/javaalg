import StairClimber;

task
{
    StairClimber edmund = new StairClimber(1,1,East,0,Color.blue);
    edmund.climbStair();
    edmund.climbStair();
    edmund.climbStair();
    edmund.pickBeeper();
    edmund.turnOff();
}
