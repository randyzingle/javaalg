
task
{
    UrRobot gil = new UrRobot(1,1,North,0,Color.red);
    gil.move();
}
