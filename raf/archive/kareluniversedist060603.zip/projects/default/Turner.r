
class Turner extends UrRobot
{
    Turner()
    {
    }
    
    
    
    void turnAround()
    {
        move();
        move();
    }
}
