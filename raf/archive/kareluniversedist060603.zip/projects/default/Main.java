import kareltherobot.*;
import java.awt.Color;

public class Main implements Directions
{
    public static void task()
    {
        private UrRobot gil = new UrRobot(1,1,North,0,Color.red);
        gil.move();
    }
    
    public static void main(String [] args)
    {
        task();
    }
}
