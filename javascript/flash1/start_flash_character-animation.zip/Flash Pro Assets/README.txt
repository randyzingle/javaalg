READ ME
Licensing and Installation of Sample Files for Flash Professional CC

Table of contents
1. Use of Sample Files.
2. Installation Instructions.

Use of Sample Files.
You can use the sample files accompanying our Getting Started tutorials 
in the ways outlined in Section 6(a) of the Adobe Terms of Use. 

In addition, you are permitted to:   
   * Modify the sample files.   
   * Copy and distribute the sample files if you agree: 	
     * Not to lease, license, rent, or sell the sample files or otherwise 
       use the sample files for commercial purposes; and 
     * Not to remove, obscure, or alter any licensing text such as 
       watermarks or proprietary notices contained in the sample files.

 The sample files are provided by Adobe "AS IS" without warranty of any kind.

   Installation Instructions.

Simply unzip the files to the desired location. The first lesson walks through creating a new project. Each folder contains the completed FLA file for the project at the end of that lesson. Further instructions will be provided in the tutorial.
